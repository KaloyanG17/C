#ifndef PIG_H
#define PIG_H

char* pig(char* word);

#endif